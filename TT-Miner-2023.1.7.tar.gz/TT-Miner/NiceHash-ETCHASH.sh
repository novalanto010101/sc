rem * Replace <YOUR_NH_WALLET_ID> and <WORKER> with the values for your nicehash wallet-id and worker name.


rem TT commandline
./TT-Miner -a ETCHASH -P stratum+ssl://<YOUR_NH_WALLET_ID>.<WORKER>@etchash.auto.nicehash.com:443
pause

