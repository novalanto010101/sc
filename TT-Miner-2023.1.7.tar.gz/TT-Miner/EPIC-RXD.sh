rem * Replace <YOUR_USERNAME>, <YOUR_PASSWORD> and <WORKER> with the values for your wallet and worker name.
rem * Replace <YOUR_RXD_WALLET> and <YOUR_RXD_WORKER> with your information for your Radiant wallet and worker


rem TT commandline
./TT-Miner -coin epic -P <YOUR_USERNAME>#<WORKER>:<YOUR_PASSWORD>@51pool.online:4416 -coinalt RXD -Palt ssl://<YOUR_RXD_WALLET>.<YOUR_RXD_WORKER>@pool.woolypooly.com:3122


pause



