rem * Your config file should look like this. You have to replace <USERNAME>, <PASSWORD> and <YOUR WALLET ID>
rem * with the values your your system. Please make sure to replace them in your config file as well as in the TT-Miner command line!!!!
rem * Replace <IP-TO-YOUR-QT-WALLET> with the IP of the computer that runs your wallet. If you run the wallet on the same machine that you 
rem * use for mining you can use 127.0.0.1 for <IP-TO-YOUR-QT-WALLET>


rem -- FILE START -- do not add this line to your config file!
rem automintoff=1
rem rpcuser=<USERNAME>
rem rpcpassword=<PASSWORD>
rem rpcbind=0.0.0.0
rem rpcallowip=192.168.41.0/24 <- sample!
rem server=1
rem listen=1
rem gen=1
rem miningaddress=<YOUR WALLET ID>
rem -- FILE END -- do not add this line to your config file!



rem TT commandline
./TT-Miner -coin SATO -P http://<USERNAME>:<PASSWORD>@<IP-TO-YOUR-QT-WALLET>:3334
