rem * 
rem * replace <SOME_ID> and <SOME_WORKER> with anything you like - it is not really used.



rem TT commandline
./TT-Miner -coin EPIC -P <SOME_ID>.<SOME_WORKER>@127.0.0.1:3416

