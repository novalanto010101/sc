rem * Replace <YOUR_WALLET_ID> and <WORKER> with the values for your wallet and worker name.


rem TT commandline
./TT-Miner -coin veil -P ssl://<YOUR_WALLET_ID>.<WORKER>@pool.woolypooly.com:3098
pause

