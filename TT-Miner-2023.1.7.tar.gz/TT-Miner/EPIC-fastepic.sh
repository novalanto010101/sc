rem * Replace <YOUR_KEYBASE_ID>, <YOUR_PASSWORD> and <WORKER> with the values for your wallet and worker name.


rem TT commandline
./TT-Miner -coin epic -P ssl://<YOUR_KEYBASE_ID>.<WORKER>:<YOUR_PASSWORD>@fastepic.eu:3416

rem TT commandline with alternate coin
rem ./TT-Miner -coin epic -P <YOUR_KEYBASE_ID>.<WORKER>:<YOUR_PASSWORD>@fastepic.eu:3416 -coinalt <ALTERNATE_COIN> -Palt <ALTERNATE_INFO>
pause

