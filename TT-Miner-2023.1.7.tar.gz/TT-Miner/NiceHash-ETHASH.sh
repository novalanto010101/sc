rem * Replace <YOUR_NH_WALLET_ID> and <WORKER> with the values for your nicehash wallet-id and worker name.


rem TT commandline
./TT-Miner -a ETHASH -P stratum+ssl://<YOUR_NH_WALLET_ID>.<WORKER>@daggerhashimoto.auto.nicehash.com:443
pause

