rem * Replace <YOUR_USERNAME>, <YOUR_PASSWORD> and <WORKER> with the values for your wallet and worker name.


rem TT commandline
./TT-Miner -coin epic -P <YOUR_USERNAME>#<WORKER>:<YOUR_PASSWORD>@51pool.online:4416

rem TT commandline with alternate coin
rem ./TT-Miner -coin epic -P <YOUR_USERNAME>#<WORKER>:<YOUR_PASSWORD>@51pool.online:4416 -coinalt <ALTERNATE_COIN> -Palt <ALTERNATE_INFO>
pause



