rem * Your call to start the ZANO stratrum should look like this. You have to replace <YOUR_WALLET_ID>
rem * with the address of your ZANO-Wallet

rem zanod.exe --stratum --stratum-miner-address=<YOUR_WALLET_ID> --stratum-bind-port=11555


rem TT commandline
./TT-Miner -luck -coin ZANO -P <YOUR_WORKER_NAME>@127.0.0.1:11555
pause
