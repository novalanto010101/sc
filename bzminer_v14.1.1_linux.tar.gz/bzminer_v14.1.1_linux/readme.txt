************************************
*                                  *
*  BzMiner v14.1 Readme            *
*                                  *
************************************

ethw (EthPOW, 0.5% dev fee)
etchash (Ethereum Classic, 0.5% dev fee)
rvn (Ravencoin, 0.5% dev fee)
olhash (Overline, 1% dev fee)
alph (Alephium, 0.5% dev fee)
kaspa (Kaspa, 1% dev fee)
ixi (Ixian, 1% dev fee)
zil (Zilliqa, 0% dev fee)
ergo (Ergo, 0.5% dev fee)
neoxa (Neoxa, 0.5% dev fee)
meowcoin (Meowcoin, 0.5% dev fee)
radiant (RDX, 1.0% dev fee)
nexa (Nexa, 2.0% dev fee)
ironfish (Ironfish, 1.0% dev fee)

### Quick Start (single coin) ###

1. Right-click and edit desired .bat file (kaspa.bat)

2. Replace 0000 with your wallet address

3. Save and close the .bat file

4. Double-click the .bat file


### Quick Start (dual mining) ###

1. Right-click and edit desired .bat file (zil_dual.bat)

2. Replace 0000 with your main (etc) coins wallet address

3. Replace 1111 with your secondary (zil) coins wallet address

3. Save and close the .bat file

4. Double-click the .bat file


### Quick Start (zil + dual mining) ###

1. Right-click and edit desired .bat file (zil_tri.bat)

2. Replace 0000 with your main (etc) coin's wallet address

3. Replace 1111 with your secondary (kaspa) coin's wallet address

4. Replace 2222 with your zil wallet address

5. Save and close the .bat file

6. Double-click the .bat file


### More options at github ###

https://github.com/bzminer/bzminer


### Discord chat ###

https://discord.gg/NRty3PCVdB
