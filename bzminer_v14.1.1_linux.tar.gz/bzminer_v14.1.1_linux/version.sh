#!/bin/sh

./bzminer --version

read -p "Press [Enter] key to start continue..."