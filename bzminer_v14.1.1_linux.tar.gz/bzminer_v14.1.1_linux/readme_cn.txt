************************************
*                                  *
*  BzMiner v14.1 Readme            *
*                                  *
************************************

ethw (EthPOW, 0.5% 开发费用)
etchash (Ethereum Classic, 0.5% 开发费用)
rvn (Ravencoin, 0.5% 开发费用)
olhash (Overline, 1% 开发费用)
alph (Alephium, 0.5% 开发费用)
kaspa (Kaspa, 1% 开发费用)
ixi (Ixian, 1% 开发费用)
zil (Zilliqa, 0% 开发费用)
ergo (Ergo, 0.5% 开发费用)
neoxa (Neoxa, 0.5% 开发费用)
meowcoin (Meowcoin, 0.5% 开发费用)
radiant (RDX, 1.0% 开发费用)
nexa (Nexa, 2.0% 开发费用)
ironfish (Ironfish, 2.0% 开发费用)


### 快速开启(单一硬币) ###

1. 选择bat文件右击后编辑 (kaspa.bat)

2. 用你的钱包地址取代0000

5. 添加 `--lang cn` 到末尾指令

3. 保存后关闭bat文件

4. 双击bat文件


### 快速开启(双重开采) ###

1. 选择bat文件右击后编辑 (zil_dual.bat)

2. 用你的首要货币（etc)钱包地址取代 0000 

3. 用你的次要货币(zil)钱包地址取代 1111 

4. 添加 `--lang cn` 到末尾指令

5. 保存后关闭bat文件

6. 双击bat文件


### 快速开启(三合一开采) ###

1. 选择bat文件右击后编辑 (zil_tri.bat)

2.用你的首要货币（etc)钱包地址取代 0000 

3. 用你的次要货币(kaspa)钱包地址取代 1111

4. 用你的zil钱包取代2222 

5. 添加 `--lang cn` 到末尾指令

6. 保存后关闭bat文件

7. 双击bat文件


### 更多选择在github ###

https://github.com/bzminer/bzminer


### Discord群聊 ###

https://discord.gg/NRty3PCVdB
